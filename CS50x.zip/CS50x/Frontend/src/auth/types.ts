export type AuthUser = {
  email: string;
  createdAt: number;
};
