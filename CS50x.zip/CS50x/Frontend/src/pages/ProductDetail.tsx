// Re-export MovieDetail (renamed)
export { default } from './MovieDetail';
