export type FavoriteMovie = {
  tmdbId: number;
  title: string;
  year?: string;
  posterUrl?: string;
  addedAt: number;
};
